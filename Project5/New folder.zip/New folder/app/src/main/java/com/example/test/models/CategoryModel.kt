package com.example.test

class CategoryModel {
    val image = ""
    val gift_name = ""
    val gift_price = ""
    val gift_description = ""
}
