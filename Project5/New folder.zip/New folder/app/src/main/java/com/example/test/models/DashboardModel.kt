package com.example.test

class DashboardModel {

    var name = ""
    var url = ""
}