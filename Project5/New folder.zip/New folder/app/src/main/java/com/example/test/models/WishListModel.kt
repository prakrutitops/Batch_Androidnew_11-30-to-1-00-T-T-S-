package com.example.test

class WishListModel {
    var id=0
    val image = ""
    val gift_name = ""
    val gift_price = ""
    val gift_description = ""
}
